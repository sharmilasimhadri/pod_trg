package org.cap.model;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AbstractApplicationContext context=
				new ClassPathXmlApplicationContext("myBeans.xml");
		
		Employee employee=(Employee)context.getBean("emp");
		
		
		System.out.println(employee);
		
		/*
		 * Employee employee1=(Employee)context.getBean("emp");
		 * employee1.setLastName("Jackson");
		 */
		/*
		 * System.out.println(employee.hashCode());
		 * System.out.println(employee1.hashCode());
		 * 
		 * System.out.println(employee.getAddress().hashCode());
		 * System.out.println(employee1.getAddress().hashCode());
		 */
		
		
		context.close();
		
	}

}
