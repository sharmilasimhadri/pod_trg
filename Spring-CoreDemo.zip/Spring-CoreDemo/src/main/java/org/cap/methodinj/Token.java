package org.cap.methodinj;

public class Token {

}
