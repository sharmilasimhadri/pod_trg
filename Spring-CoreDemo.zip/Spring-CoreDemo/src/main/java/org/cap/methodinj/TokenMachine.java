package org.cap.methodinj;

public abstract class TokenMachine {
	
	public void findToken() {
		System.out.println("Token generated:" + generateToken() );
	}

	public abstract Token generateToken();
}
