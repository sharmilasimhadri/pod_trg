package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("customerDbDao")
@Transactional
public class CustomerDBDaoImpl implements ICustomerDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Customer> getAllCustomers() {
		
		return entityManager.createQuery("from Customer").getResultList();
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		
		entityManager.persist(customer);
		return getAllCustomers();
	}

}
