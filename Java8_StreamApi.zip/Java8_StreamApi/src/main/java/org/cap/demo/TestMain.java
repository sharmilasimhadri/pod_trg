package org.cap.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class TestMain {

	public static void main(String[] args) {
		
		List<int[]> lst=new ArrayList<int[]>();
		
		lst.add(new int[]{1,2,3,4});
		lst.add(new int[]{23,45,56});
		lst.add(new int[]{2,3,4});
		lst.add(new int[]{12,45});
		
		lst.stream()
			.map((arg) ->{
				for(int n:arg)
					System.out.print(n + ",");
				System.out.println();
				return arg.length;
			})
			.forEach(System.out::println);
		
		
		
		
	}

}
