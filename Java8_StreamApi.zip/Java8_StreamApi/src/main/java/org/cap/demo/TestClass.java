package org.cap.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class TestClass {

	public static void main(String[] args) {
		List<String> list=new ArrayList<>();
		list.add("aaa");
		list.add("aaa1");
		list.add("aaa2");
		list.add("aaa3");
		list.add("bbbb");
		list.add("bbb");
		list.add("bbb1");
		list.add("bbb2");
		list.add("ccc");
		list.add("ccc1");
		list.add("ccc3");
		
		
		//list.stream()
		List<String> anslst= list.parallelStream()
			.filter((str) -> str.length()>3)
			.map((s)-> s.toUpperCase())
			.collect(Collectors.toList());
			//.forEach(System.out::println);
			
		System.out.println(anslst);
		System.out.println(list);
		
		//list.stream()
		List<String> ans= list.parallelStream()
		.filter((str) -> str.length()>3)
		.map((s)-> s.toUpperCase())
		.sorted()
		.collect(Collectors.toList());
		//.forEach(System.out::println);
		
		System.out.println(ans);
		
		long count=list.parallelStream()
		.filter((str) -> str.length()>3)
		.map((s)-> s.toUpperCase())
		.count();
		
		System.out.println("no of object:" + count);
		
		list.parallelStream()
		.filter((str) -> str.length()>3)
		.map((s)-> s.toUpperCase());
		
		
	}

}
