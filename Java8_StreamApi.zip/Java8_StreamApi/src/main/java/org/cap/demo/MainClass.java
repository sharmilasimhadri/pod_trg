package org.cap.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class MainClass {

	public static void main(String[] args) {
		
		List<String> list=new ArrayList<>();
		list.add("aaa");
		list.add("aaa1");
		list.add("aaa2");
		list.add("aaa3");
		list.add("bbbb");
		list.add("bbb");
		list.add("bbb1");
		list.add("bbb2");
		list.add("ccc");
		list.add("ccc1");
		list.add("ccc3");
		
		
		//Stream<String> streams= list.stream(); //sequential
		Stream<String> streams=list.parallelStream(); //parallel
		
		processStream(streams);
		
	}

	public static void processStream(Stream<String> str) {
		
		str.forEach((s) ->{
			System.out.println("Object  --->" + s.toUpperCase() +  "---->"+
					Thread.currentThread().getName() );
		});
		
		
	}
	
	
}
