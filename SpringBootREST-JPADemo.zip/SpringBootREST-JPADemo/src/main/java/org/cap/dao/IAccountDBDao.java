package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDbDao")
@Transactional
public interface IAccountDBDao extends JpaRepository<Account, Integer> {
//public interface IAccountDBDao extends CrudRepository<Account, Integer> {

	
	
	//JPQL query
	@Query("from Account acc where acc.accountId= :accountId or"
			+ " acc.openingBalance=:openingbalance")
	public List<Account> filterAllCapgAccounts(
			@Param("accountId")Integer accountId,
			@Param("openingbalance") double openingbalance);
	
	
	
	
	
	
	//select * from account where accountType='current'
	public List<Account> findByAccountType(String accountType);
	
	//select * from account where accountType='current' and openingbalance='1500'
	public List<Account> findByAccountTypeAndOpeningBalance
			(String accountType, double openingBalance);
	
	
	
}
