package org.cap.controller;

import java.util.List;

import org.cap.model.Account;
import org.cap.service.IAccountDBService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class AccountRestContrller {

	@Autowired
	private IAccountDBService accountDbService;
	
	/*
	 * ==============Filter Query=====================
	 */
	
	
	@GetMapping("/capgaccounts/{accountId}/{balance}")
	public ResponseEntity<List<Account>> filterCapgAccountdetails(
			@PathVariable("accountId") Integer accountId,
			@PathVariable("balance")double balance){
		List<Account> accounts= accountDbService.filterAllCapgAccounts(accountId, balance);
		
		if(accounts==null || accounts.isEmpty())
			return new ResponseEntity("Sorry! No such Accounts Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	
	@GetMapping("/accountype/{accountType}/{balance}")
	public ResponseEntity<List<Account>> findByAccountTypeAndBalance(
			@PathVariable("accountType") String accountType,
			@PathVariable("balance")double balance){
		List<Account> accounts= accountDbService.findByAccountTypeAndOpeningBalance(accountType, balance);
		
		if(accounts==null || accounts.isEmpty())
			return new ResponseEntity("Sorry! No such Accounts Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	
	
	
	@GetMapping("/accountype/{accountType}")
	public ResponseEntity<List<Account>> findByAccountType(
			@PathVariable("accountType") String accountType){
		List<Account> accounts= accountDbService.findByAccountType(accountType);
		
		if(accounts==null || accounts.isEmpty())
			return new ResponseEntity("Sorry! No such AccountType Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	
	
	
	
	
	//=====================CRUD OPeration========================
	@DeleteMapping("/account/{accountno}")
	public ResponseEntity<List<Account>> deleteAccount(
			@PathVariable("accountno")Integer accountno){
		List<Account> accounts= accountDbService.deleteAccount(accountno);
		
		if(accounts==null || accounts.isEmpty())
			return new ResponseEntity("Sorry! Deletion error!", HttpStatus.BAD_GATEWAY);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	@PutMapping("/account")
	public ResponseEntity<List<Account>> updateAccount(
			@RequestBody Account account){
		List<Account> accounts= accountDbService.updateAccount(account);
		
		if(accounts==null || accounts.isEmpty())
			return new ResponseEntity("Sorry! Updation error!", HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	@PostMapping("/account")
	public ResponseEntity<List<Account>> saveAccount(
			@RequestBody Account account){
		List<Account> accounts= accountDbService.saveAccount(account);
		
		if(accounts==null || accounts.isEmpty())
			return new ResponseEntity("Sorry! Insertion error!", HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	
	@GetMapping("/accounts")
	public ResponseEntity<List<Account>> getAllAccouts(){
		List<Account> accounts= accountDbService.getAllAccounts();
		
		if(accounts==null || accounts.isEmpty())
			return new ResponseEntity("Sorry! No Accounts Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	//@PatchMapping("account")
}
