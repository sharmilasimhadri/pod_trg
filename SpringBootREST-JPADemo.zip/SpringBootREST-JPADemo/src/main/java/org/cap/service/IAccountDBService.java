package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.springframework.data.repository.query.Param;

public interface IAccountDBService {
	
	public List<Account> getAllAccounts();
	public List<Account> saveAccount(Account account);
	public List<Account> updateAccount(Account account);
	public List<Account> deleteAccount(Integer accountno);
	public List<Account> findByAccountType(String accountType);
	
	public List<Account> findByAccountTypeAndOpeningBalance
	(String accountType, double openingBalance);
	
	public List<Account> filterAllCapgAccounts(Integer accountId,double openingbalance);
	
}
