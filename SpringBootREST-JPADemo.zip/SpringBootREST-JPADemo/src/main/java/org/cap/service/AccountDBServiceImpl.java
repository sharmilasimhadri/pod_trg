package org.cap.service;

import java.util.List;

import org.cap.dao.IAccountDBDao;
import org.cap.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("accountDbService")
public class AccountDBServiceImpl implements IAccountDBService {

	@Autowired
	private IAccountDBDao accountDbDao;
	
	@Override
	public List<Account> getAllAccounts() {
		
		
		
		return  accountDbDao.findAll();
	}

	@Override
	public List<Account> saveAccount(Account account) {
		
		accountDbDao.save(account);
		
		return getAllAccounts();
	}

	@Override
	public List<Account> updateAccount(Account account) {
		
		return saveAccount(account);
	}

	@Override
	public List<Account> deleteAccount(Integer accountno) {
		accountDbDao.deleteById(accountno);
		return getAllAccounts();
	}

	@Override
	public List<Account> findByAccountType(String accountType) {
	
		return accountDbDao.findByAccountType(accountType);
	}

	@Override
	public List<Account> findByAccountTypeAndOpeningBalance(String accountType, double openingBalance) {
		
		return accountDbDao.findByAccountTypeAndOpeningBalance(accountType, openingBalance);
	}

	@Override
	public List<Account> filterAllCapgAccounts(Integer accountId, double openingbalance) {
		
		return accountDbDao.filterAllCapgAccounts(accountId, openingbalance);
	}

}
