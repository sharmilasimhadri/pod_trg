package org.cap.model.inherit;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TEstClass {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=
				entityManagerFactory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
			Project project=new Project(1001, "SCB Cards");
			Module module=new Module();
			module.setProjectId(1234);
			module.setProjectName("TU Transactions");
			module.setModuleName("Logging Module");
			
			Task task=new Task();
			task.setProjectId(190);
			task.setProjectName("Synchrony Audit");
			task.setModuleName("Audit Module");
			task.setTaskName("Account audit Login TAsk");
		
			entityManager.persist(task);
			entityManager.persist(module);
			entityManager.persist(project);
		
		transaction.commit();
		entityManager.close();
		entityManagerFactory.close();
	}

}
