package org.cap.model.inherit;

import javax.persistence.Entity;

@Entity
public class Task extends Module{
	private String taskName;

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public Task(String taskName) {
		super();
		this.taskName = taskName;
	}

	public Task() {
		super();
		
	}
	public Task(int projectId, String projectName) {
		super(projectId, projectName);
	}

	@Override
	public String toString() {
		return "Task [taskName=" + taskName + "]";
	}
	
	

}
