package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		Circle circle=new Circle();
		circle.draw();
		circle.info();
		
		Shape.defaultColor();
	}

}
