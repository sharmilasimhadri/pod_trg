package org.cap.demo;

public class Circle implements Shape{

	@Override
	public void draw() {
		System.out.println("Drawing Circle....");
		
	}

	@Override
	public void info() {
		System.out.println("Information about Circle....");
	}
	

}
