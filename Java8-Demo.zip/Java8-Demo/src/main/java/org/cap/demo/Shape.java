package org.cap.demo;

@FunctionalInterface
public interface Shape {
	
	public void draw();
	
	default public void info() {
		System.out.println("Shape information details...");
	}
	
	public static void defaultColor() {
		System.out.println("Default Color here: Red");
	}

}
