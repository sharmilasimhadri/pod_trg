package org.cap.demo;

@FunctionalInterface
interface Printable{
	void print(String printerName);
}

public class LambdaExpreDemo {

	public static void main(String[] args) {
		
		Shape shape= () -> System.out.println("Drawing Shapes");
		Shape shape1= () -> {
			System.out.println("Drawing Shapes");
			System.out.println("Multiline Shapes");
		};
		shape.draw();
		shape1.draw();
		
		
		
		Printable printable=(str) -> System.out.println("Printer Name:" + str);
		printable.print("Network Printer-Capg");
		
		
		
		
		
		
		
		
	}

}
