package org.cap.demo;

public class Demo {
	
	public static void check() throws RuntimeException{
		System.out.println("Exception ....");
	}

	public static void main(String[] args) {

		check();

	}

}
