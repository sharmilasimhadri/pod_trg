package org.cap.java;

public class MethodRefDemo {

	public static void main(String[] args) {
		
		//Method Ref for Constructor
		//Showable emp= Employee::new;
		//emp.show(123,"Tom",45000);
		
		//static mEthod using method ref
		//Showable validate= Employee::validateEmployee;
		//validate.show();
		
		//instance method Refer
		Employee employee=new Employee();
		Showable empid=employee::getEmployeeId;
		System.out.println(empid.show());
		
	}

}
