package org.cap.java;

@FunctionalInterface
public interface Showable {

	public int show();
	//public void show(int id, String name,double salary);
}
