package org.cap.java;

public class Employee {

	private int employeeId;
	private String employeeName;
	private double salary;
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Employee(int employeeId, String employeeName, double salary) {
		System.out.println("Employee Class 3-Arg Constructor invoked");
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		System.out.println(this);
	}
	public Employee() {
		System.out.println("Employee Class No-Arg Constructor invoked");
		this.employeeId=10002;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary + "]";
	}
	
	public static void validateEmployee() {
		System.out.println("Employee instance validation goes here...............");
	}
	
}
