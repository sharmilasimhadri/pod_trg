package org.cap.streamdemo;

import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		
		Predicate<Integer> predicate= (num) -> num>10;
		Predicate<Integer> predicate1= (num) -> num<100;
		
		Predicate<Integer> predicate2= (num) -> num==0;
		
		int mynum=0;
		if(predicate.test(mynum))
			System.out.println("Positive");
		else if(predicate1.test(mynum))
			System.out.println("Negative");
		else if(predicate2.test(mynum))
			System.out.println("Zero");
		
		int n=67;
		System.out.println(predicate.and(predicate1).test(n));
		System.out.println(predicate.or(predicate1).test(200));
		System.out.println(predicate2.negate().test(0));
	}

}
