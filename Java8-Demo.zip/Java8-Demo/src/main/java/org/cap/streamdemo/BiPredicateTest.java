package org.cap.streamdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;

public class BiPredicateTest {

	public static void main(String[] args) {
	
		Employee employee=new Employee(123, "tom", "jerry", "tom123");
		Employee employee1=new Employee(324324, "kamal", "singh", "kamal124");
		Employee employee2=new Employee(21321, "jack", "kamal", "jack345");
		Employee employee3=new Employee(234324, "tom", "jerry", "tom123");
		
		
		List<Employee> employees=new ArrayList<Employee>();
		employees.add(employee3);employees.add(employee2);employees.add(employee1);
		employees.add(employee);
		
		BiPredicate<String,String> validate= 
				(userName,pwd) -> userName.equals("tom") & pwd.equals("tom123");
				
				
				employees.parallelStream()
					.filter((emp) -> validate.test(emp.getFirstName(), emp.getEmpPassword()) )
					.forEach(System.out::println);
		
	}

}
