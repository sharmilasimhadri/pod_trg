package org.cap.streamdemo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		list.add("aaaaa");
		list.add("sss");list.add("adddd");list.add("ddddd");list.add("bbbb");
		list.add("uu");list.add("aa");list.add("aaaaa");list.add("cccc");
		list.add("ss");list.add("hhh");
		
		//sequential Stream
		//Stream<String> stream= list.stream();
		Stream<String> stream= list.parallelStream();
		checkStream(stream);
	}

	public static void checkStream(Stream<String> stream) {
		stream.forEach(
				(str) ->
					System.out.println(LocalDateTime.now() + "-->"+str.toUpperCase() + "--->"
							+Thread.currentThread().getName())
					);
	
	}
	
}
