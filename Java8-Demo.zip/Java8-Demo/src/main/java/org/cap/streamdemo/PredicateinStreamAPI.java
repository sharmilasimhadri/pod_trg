package org.cap.streamdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class PredicateinStreamAPI {

	public static void main(String[] args) {
		
		List<String> list=new ArrayList<String>();
		list.add("aaaaa");
		list.add("sss");list.add("adddd");list.add("ddddd");list.add("bbbb");
		list.add("uu");list.add("aa");list.add("aaaaa");list.add("cccc");
		list.add("ss");list.add("hhh");
		
		Predicate<String> predicate= (str) -> str.length()>3;
		Predicate<String> predicate1= (str) -> str.startsWith("a");
		
		list.stream()
			//.filter(predicate.and(predicate1))
			.filter((str) -> str.length()>3 && str.startsWith("a") )
			.forEach(System.out::println);
		
	}

}
