package org.cap.dao;

import org.cap.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("customerDBDao")
@Transactional
public interface ICustomerDBDao extends JpaRepository<Customer, Integer>{

}
