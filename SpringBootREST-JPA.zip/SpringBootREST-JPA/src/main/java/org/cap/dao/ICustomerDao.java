package org.cap.dao;

import java.util.List;

import org.cap.model.Customer;

public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();

	public List<Customer> createCustomer(Customer customer);

	public Customer findCustomer(Integer custId);

	public List<Customer> deleteCustomer(Integer custId);

}
