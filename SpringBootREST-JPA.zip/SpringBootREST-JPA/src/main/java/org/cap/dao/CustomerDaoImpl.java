package org.cap.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Customer;
import org.cap.model.Product;
import org.springframework.stereotype.Repository;

@Repository("customerDao")
public class CustomerDaoImpl implements ICustomerDao {
	
	private static AtomicInteger productId=new AtomicInteger(1);
	private static List<Customer> customers=dummyDB();
	
	private static List<Customer> dummyDB(){
		List<Customer> customers=new ArrayList<Customer>();
		
		Customer tom=new Customer(1001, "Tom");
		tom.getProducts().add(new Product(productId.getAndIncrement(), "Liril", 5,23.0));
		tom.getProducts().add(new Product(productId.getAndIncrement(), "Lux", 15,27.0));
		customers.add(tom);
		
		Customer jack=new Customer(1234, "jack");
		jack.getProducts().add(new Product(productId.getAndIncrement(), "Dove", 5,45.0));
		jack.getProducts().add(new Product(productId.getAndIncrement(), "Lux", 5,27.0));
		customers.add(jack);
			
		Customer annie=new Customer(435435, "Annie");
		annie.getProducts().add(new Product(productId.getAndIncrement(), "Lifebouy", 23,22.0));
		annie.getProducts().add(new Product(productId.getAndIncrement(), "Jeeva", 10,32.0));
		customers.add(annie);
			
		
		return customers;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		customers.add(customer);
		return customers;
	}

	@Override
	public Customer findCustomer(Integer custId) {
	
		for(Customer customer:customers) {
			if(customer.getCustomerId()==custId)
				return customer;
		}
		return null;
	}

	@Override
	public List<Customer> deleteCustomer(Integer custId) {
		boolean flag=false;
		Iterator<Customer> iterator= customers.iterator();
		while(iterator.hasNext()) {
			Customer customer=iterator.next();
			if(customer.getCustomerId()==custId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		if(flag)
			return customers;
		else
			return null;
	}

}
 