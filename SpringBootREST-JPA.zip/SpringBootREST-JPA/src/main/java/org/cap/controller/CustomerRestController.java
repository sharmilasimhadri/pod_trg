package org.cap.controller;

import java.util.List;

import org.cap.dao.ICustomerDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController//@Controller + @ResponseBody
@RequestMapping("/customer/api/v1")
public class CustomerRestController {
	
	@Autowired
	private ICustomerDao customerDao;
	
	@DeleteMapping(value = "/customers/{custId}",produces = {"text/xml"})
	public ResponseEntity<List<Customer>> deleteCustomer(
			@PathVariable("custId")Integer custId){
		List<Customer> customers =customerDao.deleteCustomer(custId);
		if(customers==null )
			return new ResponseEntity("Deletion Error!CustomerId does not exists!!", 
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
		
	}
	
	
	@GetMapping("/customers/{custId}")
	public ResponseEntity<Customer> findCustomer(
			@PathVariable("custId")Integer custId){
		 Customer customer =customerDao.findCustomer(custId);
		if(customer==null )
			return new ResponseEntity("Sorry!CustomerId does not exists!!", 
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		
	}
	
	
	
	@PostMapping("/customer")
	public ResponseEntity<List<Customer>> createCustomer(
			@RequestBody Customer customer){
		List<Customer> customers=customerDao.createCustomer(customer);
		if(customers==null || customers.isEmpty())
			return new ResponseEntity("Insertion Failed!!", 
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllCustomers(){
		 List<Customer> customers =customerDao.getAllCustomers();
		if(customers==null || customers.isEmpty())
			return new ResponseEntity("Sorry! No Customer Available!", 
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
		
	}
	
}
