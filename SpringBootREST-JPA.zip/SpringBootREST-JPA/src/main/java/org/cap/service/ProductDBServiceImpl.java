package org.cap.service;

import java.util.List;

import org.cap.dao.IProductDBDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productDBService")
public class ProductDBServiceImpl implements IProductDBService{
	
	@Autowired
	private IProductDBDao productDBDao;

	@Override
	public List<Product> getAllProducts() {
		
		return productDBDao.findAll();
	}

	@Override
	public List<Product> createProduct(Product product) {
		productDBDao.save(product);
		return productDBDao.findAll();
	}

	@Override
	public Product findProduct(Integer productId) {
		Product product= productDBDao.getOne(productId);
		return product;
	}

	@Override
	public List<Product> deleteProduct(Integer productId) {
		productDBDao.deleteById(productId);
		
		return productDBDao.findAll();
	}

}
