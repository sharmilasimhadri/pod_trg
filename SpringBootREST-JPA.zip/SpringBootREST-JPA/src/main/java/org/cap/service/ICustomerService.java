package org.cap.service;

import java.util.List;

import org.cap.model.Customer;

public interface ICustomerService {
	public List<Customer> getAllCustomers();

	public List<Customer> createCustomer(Customer customer);

	public Customer findCustomer(Integer custId);

	public List<Customer> deleteCustomer(Integer custId);
}
