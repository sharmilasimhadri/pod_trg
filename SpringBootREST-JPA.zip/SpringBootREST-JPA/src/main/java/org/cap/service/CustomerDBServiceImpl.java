package org.cap.service;

import java.util.List;

import org.cap.dao.ICustomerDBDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("customerDBService")
public class CustomerDBServiceImpl implements ICustomerService{

	@Autowired
	private ICustomerDBDao customerDBDao;
	
	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDBDao.findAll();
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		customerDBDao.save(customer);
		return getAllCustomers();
	}

	@Override
	public Customer findCustomer(Integer custId) {
		Customer customer=customerDBDao.getOne(custId);
		return customer;
	}

	@Override
	public List<Customer> deleteCustomer(Integer custId) {
		customerDBDao.deleteById(custId);
		return getAllCustomers();
	}

}
