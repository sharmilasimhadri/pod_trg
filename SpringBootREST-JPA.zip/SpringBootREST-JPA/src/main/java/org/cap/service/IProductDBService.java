package org.cap.service;

import java.util.List;

import org.cap.model.Customer;
import org.cap.model.Product;

public interface IProductDBService {
	public List<Product> getAllProducts();

	public List<Product> createProduct(Product product);

	public Product findProduct(Integer productId);

	public List<Product> deleteProduct(Integer productId);
}
