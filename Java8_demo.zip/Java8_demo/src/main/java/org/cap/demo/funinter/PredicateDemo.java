package org.cap.demo.funinter;

import java.util.function.Predicate;

import org.cap.model.UserDetails;

public class PredicateDemo {

	public static void main(String[] args) {
	
		Predicate<Integer> p= (num) -> num>10;
		Predicate<Integer> p1= (num) -> num<50;
		
		System.out.println(p.and(p1).test(34));
		System.out.println(p.or(p1).test(64));
		System.out.println(p.negate().test(3));
		
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
		
		Predicate<UserDetails> usr= (str) -> str.getUserName().equals("tom");
		Predicate<UserDetails> pwd= (str) -> str.getUserPwd().equals("tom123");
		
		Predicate<UserDetails> checkUser= (user) -> {
			return usr.and(pwd).test(user);
			/*
			 * if(user.getUserName().equals("tom") && user.getUserPwd().equals("tom123"))
			 * return true; else return false;
			 */
		};
		
		
		UserDetails tom=new UserDetails("tom", "tom123");
		UserDetails jack=new UserDetails("jack", "jack345");
		
		System.out.println(checkUser.test(tom));
		System.out.println(checkUser.test(jack));
		
	}

}
