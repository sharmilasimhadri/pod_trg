package org.cap.demo.funinter;

import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		
		Supplier<Integer> count= () -> {
			int num=20;
			int c=0;
			for(int i=1;i<=num;i++)
			{
				if(i%2==0)
					c++;
			}
			return c;
		};
		
		
		System.out.println(count.get());
	}

}
