package org.cap.demo;

@FunctionalInterface
public interface Printable {

	public void print();
	//public void print(int n1,int n2);
	
	public static int addNums(int[] args ) {
		int sum=0;
		for(int n:args) {
			sum+=n;
		}
		return sum;
	}
	
	
}
