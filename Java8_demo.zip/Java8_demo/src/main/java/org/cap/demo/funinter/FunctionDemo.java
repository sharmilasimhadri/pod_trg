package org.cap.demo.funinter;

import java.util.function.Function;

import org.cap.model.UserDetails;

public class FunctionDemo {

	public static void main(String[] args) {
		
		Function<Integer, Integer> fn = (n) -> {
			int sum=0;
			for(int i=1;i<=n;i++)
				sum+=i;
			return sum;
		};
		
		int ans=fn.apply(10);
		System.out.println("Summation:" + ans);
		
		
		
		
		Function<String, Integer> myfn= (str) ->{
			System.out.println(str.toUpperCase());
			return str.length();
		};
		
		Function<UserDetails, Integer> myfn1= (user) ->{
			System.out.println(user.getUserName().toUpperCase());
			return user.getUserName().length();
		};
		
		
		
		System.out.println(myfn.apply("Capgemini Welcomes U"));
		System.out.println(myfn1.apply(new UserDetails("Kamal", "Kamal123")));
	}

}
