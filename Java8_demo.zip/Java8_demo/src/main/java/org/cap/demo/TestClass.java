package org.cap.demo;

public class TestClass {

	public static void main(String[] args) {
		/*
		 * Printable p=(num1,num2) -> { int num=100; System.out.println("num:" + num);
		 * System.out.println("Sum:" + num1+num2);
		 * System.out.println("Print Method Invoked"); };
		 * 
		 * p.print(23,12);
		 */
		
		Printable.addNums(new int[]{34,56,6767,67});
	}

}
