package org.cap.demo.funinter;

import java.util.function.BiPredicate;

public class BiPredicateDemo {
	public static void main(String[] args) {
		BiPredicate<String, Integer> p= (str,num) -> str.length()==num;
		
		System.out.println(p.test("happy", 5));
		System.out.println(p.test("happiest", 5));
	}

}
