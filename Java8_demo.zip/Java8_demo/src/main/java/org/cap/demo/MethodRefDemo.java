package org.cap.demo;

public class MethodRefDemo {

	public static void main(String[] args) {
		
		
		
	}

}
