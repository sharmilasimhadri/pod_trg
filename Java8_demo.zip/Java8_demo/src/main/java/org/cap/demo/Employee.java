package org.cap.demo;

public class Employee {
	
	
	
	public Employee() {
		System.out.println("Employee Class Default Constructor");
	}

	public void getEmployee() {
		System.out.println("Employee Class Get Employee Method.");
	}
	
	
	public static void calculateSalary() {
		System.out.println("Employee Class calculate Salary Impl....");
	}
}
