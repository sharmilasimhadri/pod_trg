package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		//Method Reference of Constructor
		Printable p=Employee::new;
		p.print();
		
		//static method reference 
		Printable p1=Employee::calculateSalary;
		p1.print();
		
		
		//intance method
		//Employee employee=new Employee();
		Printable p2=new Employee()::getEmployee;
		p2.print();
		
		
		
		
	}

}
