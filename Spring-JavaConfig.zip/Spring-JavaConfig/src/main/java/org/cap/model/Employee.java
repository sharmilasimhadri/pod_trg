package org.cap.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee {
	
	private int employeeId;
	private String firstName;
	private String lastName;
	private double salary;
	
	@Autowired
	private Address address;
	
	public void init_method(){
		System.out.println("Employee Bean initialized..................");
	}
	public void destroy_method(){
		System.out.println("Employee Bean destroyed.................");
	}
	
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		System.out.println("Calling setter method - address");
		this.address = address;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Employee(int employeeId, String firstName, String lastName, double salary) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	public Employee() {
		super();
		System.out.println("Calling constrcutor with No args");
	}
	

	public Employee(int employeeId, String firstName, String lastName, double salary, Address address) {
		super();
		System.out.println("Calling constrcutor with 5 args");
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", address=" + address + "]";
	}
	
	

}
