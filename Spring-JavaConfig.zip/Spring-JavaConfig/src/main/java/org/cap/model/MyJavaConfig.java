package org.cap.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyJavaConfig {

	@Bean
	public Employee getEmployeeBean() {
		Employee employee=new Employee();
		employee.setEmployeeId(12000);
		employee.setFirstName("kamal");
		employee.setLastName("singh");
		employee.setSalary(23000);
		return employee;
	}
	
	
	@Bean(name="address")
	public Address getAddressBean() {
		Address address=new Address(123, "West Car Street", "Chennai");
		return address;
	}
	
	@Bean(name="address1")
	public Address getAddressBean1() {
		Address address=new Address(455, "East Car Street", "Mumbai");
		return address;
	}
	
}
