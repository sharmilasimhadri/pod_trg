package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Address;
import org.cap.model.Company;
import org.cap.model.Employee;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("capg");
		
		EntityManager entityManager=
					emf.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		transaction.begin();
			Address address=new Address("North Avvenue", "Pune");
			Employee employee=new Employee("Tom", 12000, address);
			
			Address address1=new Address("South Avvenue", "Hyderabad");
			Employee employee1=new Employee("Jack", 23000, address1);
			
			Address address2=new Address("South Car Street", "Chennai");
			Employee employee2=new Employee("Annie", 12300, address2);
			
			
			Company company=new Company("Capgemini India Pvt ltd");
			Company company1=new Company("TATA Consultancy");
			employee.setCompany(company);
			employee1.setCompany(company);
			employee2.setCompany(company1);
			
			
			entityManager.persist(company1);
			entityManager.persist(company);
			
			entityManager.persist(employee);
			entityManager.persist(employee1);
			entityManager.persist(employee2);
			//entityManager.persist(address);
			
			
		transaction.commit();
		entityManager.close();
		emf.close();
	}

}
