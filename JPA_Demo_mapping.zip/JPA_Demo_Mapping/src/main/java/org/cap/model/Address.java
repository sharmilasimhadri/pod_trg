package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "myseq",initialValue = 1000)
public class Address {
	
	@Id
	@GeneratedValue(generator = "myseq",strategy = GenerationType.SEQUENCE)
	private int addressId;
	private String addressLine;
	private String city;
	
	/*
	 * @OneToOne private Employee employee;
	 */
	
	
	
	public int getAddressId() {
		return addressId;
	}
	public Address(String addressLine, String city) {
		super();
		this.addressLine = addressLine;
		this.city = city;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", addressLine=" + addressLine + ", city=" + city + "]";
	}
	public Address(int addressId, String addressLine, String city) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
		this.city = city;
	}
	public Address() {
		super();
	}
	
	

}
