package org.cap.demo;

public class TestAccount {

	public static void main(String[] args) {
		
		Account account=new Account(5000);
		
		Runnable r=new Runnable() {
			
			@Override
			public void run() {
				
				account.withdraw(3000);
			}
		};
		
		Runnable r1=new Runnable() {
			
			@Override
			public void run() {
				
				account.withdraw(4000);
			}
		};
		
		Runnable r2=new Runnable() {
			
			@Override
			public void run() {
				
				account.deposit(4000);
			}
		};
		
		Runnable r3=new Runnable() {
			
			@Override
			public void run() {
				
				account.withdraw(4000);
			}
		};
		
		
		Thread t1=new Thread(r);
		Thread t2=new Thread(r1);
		Thread t3=new Thread(r2);
		Thread t4=new Thread(r3);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
	}

}
