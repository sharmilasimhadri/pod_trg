package org.cap.demo;

public class MyClass extends Thread{
	private int num;
	
	public MyClass(int num) {
		this.num=num;
	}

	public MyClass(int num,String threadName) {
		super(threadName);
		this.num=num;
		
	}

	
	
	
	
	/*
	 * @Override public synchronized void start() {
	 * 
	 * System.out.println("Thread Started...............Runnable Stage....." +
	 * Thread.currentThread().getName()); run(); }
	 */
	 




	@Override
	public void run() {
		System.out.println("Thread Running...............Running Stage....."
				+ Thread.currentThread().getName());
		for(int i=1;i<=20;i++) {
		
			System.out.println(i + "*" + num + "=" + (i*num));
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	
}
