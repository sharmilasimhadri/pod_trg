package org.cap.demo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//ScheduledThreadPoolExecutor
//Counter
//ForkAndJoin

public class ExecuterDemo {

	public static void main(String[] args) {
		
		ExecutorService service= Executors.newFixedThreadPool(5);
		
		for(int i=0;i<15;i++) {
			WorkerThread thread=new WorkerThread("Task - " + i);
			//start the thread
			service.execute(thread);
		}
		
		service.shutdown();
		
	}

}
