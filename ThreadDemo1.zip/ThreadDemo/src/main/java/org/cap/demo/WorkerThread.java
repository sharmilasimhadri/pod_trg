package org.cap.demo;

public class WorkerThread implements Runnable{
	
	private String work;
	
	public WorkerThread(String workName) {
		this.work=workName;
	}

	@Override
	public void run() {
		System.out.println("Thread Work Started." + Thread.currentThread().getName() +"-->WorkName" + this.work);
		processTask(); 
		System.out.println("Thread Work Completed." + Thread.currentThread().getName() );
	}

	
	public void processTask() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
