package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		
		//MyClass t=new MyClass(12,"T1");
		
		Thread t=new Thread() {
			@Override
			public void run() {
				for(int i=0;i<1000;i++)
					System.out.println("Thread t-->" + i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		t.setDaemon(true);
		
		t.start();
		
		/*
		 * try { t.join(); } catch (InterruptedException e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); }
		 */
		
		MyClass t1=new MyClass(15,"T2");
		t1.start();
		
		
		
		MyClass t2=new MyClass(17,"T3");
		t2.start();
	}

}
